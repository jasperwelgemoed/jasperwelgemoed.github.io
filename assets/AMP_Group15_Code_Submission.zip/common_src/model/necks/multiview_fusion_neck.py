# model/necks/multiview_fusion_neck.py

import torch
import torch.nn as nn
import torch.nn.functional as F

class MultiViewFusionNeck(nn.Module):
    """
    A multi-view fusion neck module that combines features from
    voxel-based representations and Bird's Eye View (BEV) representations
    using a learned gating mechanism.

    Args:
        voxel_channels (int): Number of input channels from the voxel feature path (e.g., backbone output).
        bev_channels (int): Number of input channels from the BEV feature path (e.g., primary neck output).
        out_channels (int): Number of output channels after fusion. This will also be the internal
                            channel dimension for the fusion operation.
    """
    def __init__(self, voxel_channels, bev_channels, out_channels):
        super(MultiViewFusionNeck, self).__init__()

        # Reduce/transform voxel features to a common channel dimension `out_channels`
        # This enables `v` and `b` to be element-wise combined later.
        self.voxel_reduce = nn.Conv2d(voxel_channels, out_channels, kernel_size=1)
        # Reduce/transform BEV features to a common channel dimension `out_channels`
        self.bev_reduce = nn.Conv2d(bev_channels, out_channels, kernel_size=1)

        # Gating mechanism:
        # This convolution takes the concatenated features (2 * out_channels)
        # and predicts channel-wise and spatially-wise gates (out_channels).
        self.gate_conv = nn.Conv2d(out_channels * 2, out_channels, kernel_size=1)
        self.sigmoid = nn.Sigmoid() # Ensures gate values are between 0 and 1.

        # Final fusion convolution after the gated sum.
        # This now operates on `out_channels` as input, as the gated sum already
        # results in `out_channels` dimensions.
        self.fusion_conv = nn.Sequential(
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )

        # Optional: Initialize gate bias to a small positive value (e.g., 0)
        # so that sigmoid(0) = 0.5, encouraging an initial equal blend of both features.
        # nn.init.constant_(self.gate_conv.bias, 0.0)

    def forward(self, voxel_feat, bev_feat):
        """
        Forward pass for the MultiViewFusionNeck with gating.

        Args:
            voxel_feat (torch.Tensor): Features from the voxel path (e.g., backbone output).
                                       Expected shape: (N, C_voxel, H, W)
            bev_feat (torch.Tensor): Features from the BEV path (e.g., primary neck output).
                                     Expected shape: (N, C_bev, H, W)

        Returns:
            torch.Tensor: Fused features after processing.
                          Expected shape: (N, out_channels, H, W)
        """
        # 1. Reduce/transform features to a common channel dimension
        # v will have shape (N, out_channels, H, W)
        v = self.voxel_reduce(voxel_feat)
        # b will have shape (N, out_channels, H, W)
        b = self.bev_reduce(bev_feat)

        # 2. Concatenate features for gate prediction
        # The gate will learn from the combined information of both views.
        # Shape: (N, 2 * out_channels, H, W)
        combined_for_gate = torch.cat([v, b], dim=1)
        
        # 3. Predict the gate weights
        # The output of gate_conv will be (N, out_channels, H, W)
        # Sigmoid squashes values between 0 and 1.
        gate = self.sigmoid(self.gate_conv(combined_for_gate))

        # 4. Apply gating: Weighted sum fusion
        # This is the core of gated fusion. For each channel and spatial location,
        # the model learns to assign a weight 'gate' to `v` and `(1 - gate)` to `b`.
        # This makes the fusion adaptive, allowing the model to prioritize one view
        # over another based on the specific features being processed.
        gated_fused_features = v * gate + b * (1 - gate)

        # 5. Apply final fusion convolution to further process the blended features
        return self.fusion_conv(gated_fused_features)