import sys
import os
repo_root = os.path.abspath(os.path.join(os.getcwd(), '../..'))
if repo_root not in sys.path:
    sys.path.append(repo_root)

from common_src.dataset import ViewOfDelft, collate_vod_batch
from torch.utils.data import DataLoader

dataset = ViewOfDelft(
    data_root=os.path.join(os.getcwd(), 'data/view_of_delft'),
    split='train',
    use_pointpainting=True
)

loader = DataLoader(dataset, batch_size=2, collate_fn=collate_vod_batch)

sample_batch = next(iter(loader))

print("Dataloader test passed.")
print("Keys:", sample_batch.keys())
print("LiDAR shape (batch 0):", sample_batch['pts'][0].shape)
print("GT Boxes shape (batch 0):", sample_batch['gt_bboxes_3d'][0].tensor.shape)
