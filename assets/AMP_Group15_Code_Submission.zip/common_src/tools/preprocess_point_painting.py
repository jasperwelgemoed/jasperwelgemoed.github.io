import os
import numpy as np
import argparse
import torch
import torchvision.transforms as T
import torch.nn.functional as F
from tqdm import tqdm
from vod.configuration import KittiLocations
from vod.frame import FrameDataLoader, FrameTransformMatrix, homogeneous_transformation
from torchvision.models.segmentation import deeplabv3_resnet50, DeepLabV3_ResNet50_Weights

def preprocess_painted_lidar(data_root='data/view_of_delft', split='train'):
    os.makedirs(os.path.join(data_root, "painted_lidar"), exist_ok=True)
    split_file = os.path.join(data_root, 'lidar', 'ImageSets', f'{split}.txt')
    
    with open(split_file, 'r') as f:
        sample_list = [line.strip() for line in f.readlines()]

    seg_model = deeplabv3_resnet50(weights=DeepLabV3_ResNet50_Weights.DEFAULT).eval()
    transform = T.Compose([
        T.ToPILImage(),
        T.Resize(520),
        T.ToTensor(),
        T.Normalize(mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]),
    ])

    kitti_locations = KittiLocations(root_dir=data_root)

    for num_frame in tqdm(sample_list, desc=f"Preprocessing {split}"):
        frame = FrameDataLoader(kitti_locations, frame_number=num_frame)
        image = frame.image
        lidar = frame.lidar_data
        xyz = lidar[:, :3]
        xyz_hom = np.hstack((xyz, np.ones((xyz.shape[0], 1))))
        
        transforms = FrameTransformMatrix(frame)
        xyz_cam = homogeneous_transformation(xyz_hom, transforms.t_camera_lidar)
        proj = xyz_cam @ transforms.camera_projection_matrix.T
        uv = (proj[:, :2].T / proj[:, 2]).T

        H, W, _ = image.shape
        valid = (proj[:, 2] > 0) & (uv[:, 0] >= 0) & (uv[:, 0] < W) & (uv[:, 1] >= 0) & (uv[:, 1] < H)
        uv_int = uv[valid].astype(np.int32)

        input_tensor = transform(image).unsqueeze(0)
        with torch.no_grad():
            output = seg_model(input_tensor)['out']
            class_map = output.argmax(1).squeeze(0)

        class_map_resized = F.interpolate(
            class_map.unsqueeze(0).unsqueeze(0).float(),
            size=image.shape[:2],
            mode='nearest'
        ).squeeze().long().numpy()

        painted_classes = class_map_resized[uv_int[:, 1], uv_int[:, 0]]
        one_hot = np.eye(21)[painted_classes]
        painted_lidar = np.hstack((xyz[valid], one_hot))  # [N, 3+21]

        # Save
        out_path = os.path.join(data_root, "painted_lidar", f"{num_frame}.npy")
        np.save(out_path, painted_lidar)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--split', type=str, choices=['train', 'val', 'test'], default='train')
    parser.add_argument('--data_root', type=str, default='data/view_of_delft')
    args = parser.parse_args()

    preprocess_painted_lidar(data_root=args.data_root, split=args.split)

