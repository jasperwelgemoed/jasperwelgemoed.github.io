from .view_of_delft import ViewOfDelft
from .utils import collate_vod_batch