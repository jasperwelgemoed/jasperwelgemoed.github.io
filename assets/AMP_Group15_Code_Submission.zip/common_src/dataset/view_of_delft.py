# import os
# import numpy as np
# from common_src.model.utils import LiDARInstance3DBoxes

# import torch
# from torch.utils.data import Dataset

# from vod.configuration import KittiLocations
# from vod.frame import FrameDataLoader, FrameTransformMatrix, homogeneous_transformation

# #########################################################################################
# import torchvision.transforms as T
# import torch.nn.functional as F
# import sys
# #########################################################################################

# class ViewOfDelft(Dataset):
#     CLASSES = ['Car', 
#                'Pedestrian', 
#                'Cyclist',]
#             #    'rider', 
#             #    'unused_bicycle', 
#             #    'bicycle_rack', 
#             #    'human_depiction', 
#             #    'moped_or_scooter', 
#             #    'motor',
#             #    'truck',
#             #    'other_ride',
#             #    'other_vehicle',
#             #    'uncertain_ride'
    
#     LABEL_MAPPING = {
#         'class': 0, # Describes the type of object: 'Car', 'Pedestrian', 'Cyclist', etc.
#         'truncated': 1, # Not used, only there to be compatible with KITTI format.
#         'occluded': 2, # Integer (0,1,2) indicating occlusion state 0 = fully visible, 1 = partly occluded 2 = largely occluded.
#         'alpha': 3, # Observation angle of object, ranging [-pi..pi]
#         'bbox2d': slice(4,8),
#         'bbox3d_dimensions': slice(8,11), # 3D object dimensions: height, width, length (in meters).
#         'bbox3d_location': slice(11,14), # 3D object location x,y,z in camera coordinates (in meters).
#         'bbox3d_rotation': 14, # Rotation around -Z-axis in LiDAR coordinates [-pi..pi].
#     }
    
#     def __init__(self, 
#                  data_root = 'data/view_of_delft', 
#                  sequential_loading=False,
#                  split = 'train',
#                  ##########################################
#                  use_pointpainting=False,
#                  use_aug=False):
#                  ##########################################
#         super().__init__()

#         ###################################################
#         self.use_pointpainting = use_pointpainting
#         self.use_aug = use_aug
#         ###################################################
        
#         self.data_root = data_root
#         assert split in ['train', 'val', 'test'], f"Invalid split: {split}. Must be one of ['train', 'val', 'test']"
#         self.split = split
#         split_file = os.path.join(data_root, 'lidar', 'ImageSets', f'{split}.txt')

#         with open(split_file, 'r') as f:
#             lines = f.readlines()
#             self.sample_list = [line.strip() for line in lines]
        
#         self.vod_kitti_locations = KittiLocations(root_dir = data_root)

#         ###########################################################################
#         if self.use_pointpainting:
#             from torchvision.models.segmentation import deeplabv3_mobilenet_v3_large, DeepLabV3_MobileNet_V3_Large_Weights
#             weights = DeepLabV3_MobileNet_V3_Large_Weights.DEFAULT
#             self.seg_model = deeplabv3_mobilenet_v3_large(weights=weights).eval()

#             # Explicitly set device attribute
#             # self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#             # self.seg_model.to(self.device)  # <--- THIS must run before workers start

#             # self.seg_model.to('cuda')

#             self.img_transform = T.Compose([
#                 T.ToPILImage(),
#                 # T.Resize(384),
#                 T.ToTensor(),
#                 T.Normalize(mean=[0.485, 0.456, 0.406],
#                             std=[0.229, 0.224, 0.225]),
#             ])

        
#         if self.use_aug:
#             self.img_aug = T.Compose([
#                 T.ToPILImage(),
#                 T.RandomHorizontalFlip(p=0.5),
#                 T.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.3, hue=0.1),
#                 T.ToTensor(),
#             ])
#         ###########################################################################

#     def __len__(self):
#         return len(self.sample_list)

#     def __getitem__(self, idx):
#         num_frame = self.sample_list[idx]

#         # ######## START FIX ########
#         vod_frame_data = FrameDataLoader(kitti_locations=self.vod_kitti_locations, frame_number=num_frame)
#         transforms = FrameTransformMatrix(vod_frame_data)
#         image = vod_frame_data.image
#         lidar_data = vod_frame_data.lidar_data
#         # ######## END FIX ########

#         ########################### BEGIN AUGMENTATION ##########################
#         if self.use_aug and self.split == "train" and np.random.rand() < 2/3:
#             # Horizontal flip
#             if np.random.rand() < 0.5:
#                 image = np.fliplr(image).copy()
#                 lidar_data[:, 1] = -lidar_data[:, 1]

#             # Color jitter
#             if np.random.rand() < 0.5:
#                 image = T.ToPILImage()(image)
#                 image = T.ColorJitter(
#                     brightness=0.3,
#                     contrast=0.3,
#                     saturation=0.3,
#                     hue=0.1
#                 )(image)
#                 image = np.array(image).copy()

#             # Grayscale
#             if np.random.rand() < 0.5:
#                 image = T.ToPILImage()(image)
#                 image = T.Grayscale(num_output_channels=3)(image)
#                 image = np.array(image).copy()

#         # Always convert to tensor afterward
#         image = T.ToTensor()(image)
#         ############################ END AUGMENTATION ###########################


#         # device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

#         gt_labels_3d_list = []
#         gt_bboxes_3d_list = []
#         if self.split != 'test':
#             raw_labels = vod_frame_data.raw_labels
#             for idx, label in enumerate(raw_labels):
#                 label = label.split(' ')
                
#                 if label[self.LABEL_MAPPING['class']] in self.CLASSES: 

#                     gt_labels_3d_list.append(int(self.CLASSES.index(label[self.LABEL_MAPPING['class']])))

#                     bbox3d_loc_camera = np.array(label[self.LABEL_MAPPING['bbox3d_location']])
#                     trans_homo_cam = np.ones((1,4))
#                     trans_homo_cam[:, :3] = bbox3d_loc_camera
#                     bbox3d_loc_lidar = homogeneous_transformation(trans_homo_cam, transforms.t_lidar_camera)
                    
#                     bbox3d_locs = np.array(bbox3d_loc_lidar[0,:3], dtype=np.float32)         
#                     bbox3d_dims = np.array(label[self.LABEL_MAPPING['bbox3d_dimensions']], dtype=np.float32)[[2, 1, 0]] # hwl -> lwh
#                     bbox3d_rot = np.array([label[self.LABEL_MAPPING['bbox3d_rotation']]], dtype=np.float32)
                
#                     gt_bboxes_3d_list.append(np.concatenate([bbox3d_locs, bbox3d_dims, bbox3d_rot], axis=0))

#         if gt_bboxes_3d_list == []:
#             gt_labels_3d = np.array([0])
#             gt_bboxes_3d = np.zeros((1,7))
#         else:
#             gt_labels_3d = np.array(gt_labels_3d_list, dtype=np.int64)
#             gt_bboxes_3d = np.stack(gt_bboxes_3d_list, axis=0)

#         gt_bboxes_3d = LiDARInstance3DBoxes(
#             gt_bboxes_3d,
#             box_dim=gt_bboxes_3d.shape[-1],
#             origin=(0.5, 0.5, 0))
#         gt_labels_3d = torch.tensor(gt_labels_3d)

#         ############################################# PointPainting #################################################
#         if self.use_pointpainting:
#             # input_tensor = self.img_transform(image).unsqueeze(0)
#             input_tensor = T.Resize(384)(image).unsqueeze(0)
#             input_tensor = T.Normalize(mean=[0.485, 0.456, 0.406],
#                                     std=[0.229, 0.224, 0.225])(input_tensor)


#             with torch.inference_mode():
#                 seg_output = self.seg_model(input_tensor)['out']  # [1, 21, H', W']

#             seg_logits = seg_output.squeeze(0)  # [21, H', W']
#             seg_probs = F.softmax(seg_logits, dim=0)
#             seg_probs_resized = F.interpolate(
#                 seg_probs.unsqueeze(0), size=image.shape[:2], mode='bilinear', align_corners=False
#             ).squeeze(0)  # [21, H, W]

#             # Select 3 semantic classes
#             bike_prob = (seg_probs_resized[2] + seg_probs_resized[4]) / 2
#             semantic_features = torch.stack([
#                 seg_probs_resized[3],  # Car
#                 seg_probs_resized[1],  # Pedestrian
#                 bike_prob              # Cyclist
#             ], dim=0)  # [3, H, W]

#             # Project LiDAR points to image
#             lidar_data = lidar_data[:, :3]
#             if isinstance(lidar_data, np.ndarray):
#                 lidar_data = torch.tensor(lidar_data, dtype=torch.float32)
#             xyz = lidar_data

#             xyz_hom = torch.cat([xyz, torch.ones((xyz.shape[0], 1), device=xyz.device)], dim=1)
#             xyz_cam = torch.tensor(
#                 homogeneous_transformation(xyz_hom.cpu().numpy(), transforms.t_camera_lidar),
#                 device=xyz.device
#             )
#             proj = xyz_cam @ torch.tensor(transforms.camera_projection_matrix.T, device=xyz.device, dtype=xyz_cam.dtype)
#             uv = proj[:, :2] / proj[:, 2:3]

#             uv_int = uv.round().long()
#             H, W = image.shape[:2]
#             uv_int[:, 0] = uv_int[:, 0].clamp(0, W - 1)
#             uv_int[:, 1] = uv_int[:, 1].clamp(0, H - 1)
#             valid = proj[:, 2] > 0

#             uv_int_valid = uv_int[valid]
#             u = uv_int_valid[:, 0]
#             v = uv_int_valid[:, 1]
#             semantic_feats = semantic_features[:, v, u].T  # [N_valid, 3]

#             lidar_data = torch.cat([xyz[valid], semantic_feats.to(xyz.device)], dim=1)
#         ######################################################################################################################

#         ##################################### DEBUG ###########################################
#         if not isinstance(lidar_data, torch.Tensor):
#             lidar_data = torch.tensor(lidar_data).float()

#         if self.use_pointpainting:
#             expected_feature_dim = 6
#             if lidar_data.shape[1] < expected_feature_dim:
#                 padded = torch.zeros((lidar_data.shape[0], expected_feature_dim), dtype=lidar_data.dtype)
#                 padded[:, :lidar_data.shape[1]] = lidar_data
#                 lidar_data = padded
#             elif lidar_data.shape[1] > expected_feature_dim:
#                 lidar_data = lidar_data[:, :expected_feature_dim]

#             if idx == 0:
#                 print("PointPainting is ACTIVE for split:", self.split)
#                 print("DEBUG: Lidar shape after painting:", lidar_data.shape)
#                 sys.stdout.flush()
#         else:
#             expected_feature_dim = 4
#             if lidar_data.shape[1] < expected_feature_dim:
#                 padded = torch.zeros((lidar_data.shape[0], expected_feature_dim), dtype=lidar_data.dtype)
#                 padded[:, :lidar_data.shape[1]] = lidar_data
#                 lidar_data = padded
#             elif lidar_data.shape[1] > expected_feature_dim:
#                 lidar_data = lidar_data[:, :expected_feature_dim]

#             if idx == 0:
#                 print("PointPainting is OFF for split:", self.split)
#                 print("DEBUG: Lidar shape without painting:", lidar_data.shape)
#                 sys.stdout.flush()

#         if idx == 0 and self.use_aug:
#             print("Data augmentation ACTIVE for split:", self.split)
#             sys.stdout.flush()
#         #######################################################################################

        
#         return dict(
#             lidar_data = lidar_data,
#             gt_labels_3d = gt_labels_3d,
#             gt_bboxes_3d = gt_bboxes_3d,
#             meta = dict(
#                 num_frame = num_frame 
#             )
#         )
    

    
import os
import numpy as np
from common_src.model.utils import LiDARInstance3DBoxes

import torch
from torch.utils.data import Dataset

from vod.configuration import KittiLocations
from vod.frame import FrameDataLoader, FrameTransformMatrix, homogeneous_transformation

############################### NEW IMPORTS #########################################
from PIL import Image, ImageOps
import torchvision.transforms as T
import random
#####################################################################################

class ViewOfDelft(Dataset):
    CLASSES = ['Car', 
               'Pedestrian', 
               'Cyclist',]
            #    'rider', 
            #    'unused_bicycle', 
            #    'bicycle_rack', 
            #    'human_depiction', 
            #    'moped_or_scooter', 
            #    'motor',
            #    'truck',
            #    'other_ride',
            #    'other_vehicle',
            #    'uncertain_ride'
    
    LABEL_MAPPING = {
        'class': 0, # Describes the type of object: 'Car', 'Pedestrian', 'Cyclist', etc.
        'truncated': 1, # Not used, only there to be compatible with KITTI format.
        'occluded': 2, # Integer (0,1,2) indicating occlusion state 0 = fully visible, 1 = partly occluded 2 = largely occluded.
        'alpha': 3, # Observation angle of object, ranging [-pi..pi]
        'bbox2d': slice(4,8),
        'bbox3d_dimensions': slice(8,11), # 3D object dimensions: height, width, length (in meters).
        'bbox3d_location': slice(11,14), # 3D object location x,y,z in camera coordinates (in meters).
        'bbox3d_rotation': 14, # Rotation around -Z-axis in LiDAR coordinates [-pi..pi].
    }
    
    def __init__(self, 
                 data_root = 'data/view_of_delft', 
                 sequential_loading=False,
                 split = 'train',
                 ################## Augmentation #####################
                 cfg=None
                 #####################################################
                 ):
        super().__init__()
        
        self.data_root = data_root
        assert split in ['train', 'val', 'test'], f"Invalid split: {split}. Must be one of ['train', 'val', 'test']"
        self.split = split
        split_file = os.path.join(data_root, 'lidar', 'ImageSets', f'{split}.txt')

        with open(split_file, 'r') as f:
            lines = f.readlines()
            self.sample_list = [line.strip() for line in lines]

        ##################################### Augmentation #########################################
        self.use_augmentation = cfg.get("use_aug", False) if cfg else False

        if self.use_augmentation and self.split == "train":
            print("Augmentation Activated for training split.")
        ############################################################################################
        
        self.vod_kitti_locations = KittiLocations(root_dir = data_root)
    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):
        num_frame = self.sample_list[idx]
        vod_frame_data = FrameDataLoader(kitti_locations=self.vod_kitti_locations,
                                         frame_number=num_frame)
        local_transforms = FrameTransformMatrix(vod_frame_data)
        
        lidar_data = vod_frame_data.lidar_data

        ###############################################################################
        rgb = vod_frame_data.image  # load RGB image here
        ###############################################################################
        
        gt_labels_3d_list = []
        gt_bboxes_3d_list = []
        if self.split != 'test':
            raw_labels = vod_frame_data.raw_labels
            for idx, label in enumerate(raw_labels):
                label = label.split(' ')
                
                if label[self.LABEL_MAPPING['class']] in self.CLASSES: 

                    gt_labels_3d_list.append(int(self.CLASSES.index(label[self.LABEL_MAPPING['class']])))

                    bbox3d_loc_camera = np.array(label[self.LABEL_MAPPING['bbox3d_location']])
                    trans_homo_cam = np.ones((1,4))
                    trans_homo_cam[:, :3] = bbox3d_loc_camera
                    bbox3d_loc_lidar = homogeneous_transformation(trans_homo_cam, local_transforms.t_lidar_camera)
                    
                    bbox3d_locs = np.array(bbox3d_loc_lidar[0,:3], dtype=np.float32)         
                    bbox3d_dims = np.array(label[self.LABEL_MAPPING['bbox3d_dimensions']], dtype=np.float32)[[2, 1, 0]] # hwl -> lwh
                    bbox3d_rot = np.array([label[self.LABEL_MAPPING['bbox3d_rotation']]], dtype=np.float32)
                
                    gt_bboxes_3d_list.append(np.concatenate([bbox3d_locs, bbox3d_dims, bbox3d_rot], axis=0))

        lidar_data = torch.tensor(lidar_data)
        
        if gt_bboxes_3d_list == []:
            gt_labels_3d = np.array([0])
            gt_bboxes_3d = np.zeros((1,7))
        else:
            gt_labels_3d = np.array(gt_labels_3d_list, dtype=np.int64)
            gt_bboxes_3d = np.stack(gt_bboxes_3d_list, axis=0)
        
        gt_bboxes_3d = LiDARInstance3DBoxes(
            gt_bboxes_3d,
            box_dim=gt_bboxes_3d.shape[-1],
            origin=(0.5, 0.5, 0))
        
        gt_labels_3d = torch.tensor(gt_labels_3d)

        ################################################# Image Augmentation #################################################
        flip = False

        if self.use_augmentation and self.split == "train" and np.random.rand() < 0.5:
            # Horizontal flip
            if np.random.rand() < 0.5:
                rgb = np.fliplr(rgb).copy()
                lidar_data[:, 1] = -lidar_data[:, 1]  # Flip y-axis (assuming LiDAR points are [x, y, z, ...])
                flip = True

            # Convert to PIL for color transforms
            rgb = T.ToPILImage()(rgb)

            # Color jitter
            if np.random.rand() < 0.5:
                rgb = T.ColorJitter(
                    brightness=0.3,
                    contrast=0.3,
                    saturation=0.3,
                    hue=0.1
                )(rgb)

            # Grayscale
            if np.random.rand() < 0.5:
                rgb = T.Grayscale(num_output_channels=3)(rgb)

            # Convert back to NumPy
            rgb = np.array(rgb).copy()

        # # Convert to tensor (always)
        # if isinstance(rgb, np.ndarray):
        #     rgb = T.ToPILImage()(rgb)
        # rgb = T.ToTensor()(rgb)

        # Flip GT boxes if scene was flipped
        if flip and self.split == 'train' and gt_bboxes_3d.tensor.shape[0] > 0:
            gt_tensor = gt_bboxes_3d.tensor.clone()
            gt_tensor[:, 1] = -gt_tensor[:, 1]
            gt_tensor[:, 6] = -gt_tensor[:, 6]
            gt_bboxes_3d = LiDARInstance3DBoxes(
                gt_tensor,
                box_dim=gt_tensor.shape[-1],
                origin=(0.5, 0.5, 0)
            )
        ######################################################################################################################
        
        return dict(
            lidar_data = lidar_data,
            gt_labels_3d = gt_labels_3d,
            gt_bboxes_3d = gt_bboxes_3d,
            meta = dict(
                num_frame = num_frame,
                #################################################################################################
                rgb=rgb,  # include RGB image
                t_lidar_to_cam=local_transforms.t_camera_lidar,  # include transformation
                camera_projection_matrix=local_transforms.camera_projection_matrix,  # include projection matrix
                split = self.split
                #################################################################################################
            )
        )
    